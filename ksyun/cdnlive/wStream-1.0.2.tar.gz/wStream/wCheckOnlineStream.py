
'''
    Copyright (C) Wang Linsen
'''

import urllib
import os
import sys
import getopt
import threading
import json
import time
import argparse

import wCheckStream

wCheckJson = '''
    {
        "items":[
            {
                "name":"gifshow",
                "rtmp":"",
                "http":"gifshow.hdllive.ks-cdn.com",
                "dashboard":"gifshow.dashboard.ks-cdn.com"
            },
            {
                "name":"momo",
                "rtmp":"",
                "http":"momo.hdllive.ks-cdn.com",
                "dashboard":"momo.dashboard.ks-cdn.com"
            },
            {
                "name":"yeye",
                "rtmp":"",
                "http":"hdl.yeyeshow.tv",
                "dashboard":"yeye.dashboard.ks-cdn.com"
            }
        ]
        
    }
'''

class wConfig():
    def __init__(self, maxThreads, checkStreamNum, checkTime, testTool):
        self.maxThreads = maxThreads
        self.checkStreamNum = checkStreamNum
        self.checkTime = checkTime
        self.testTool = testTool

class wUserTest(wCheckStream.wTest):
    '''
            ti = wFfprobeStreamTest(item['name'], item['rtmp'], item['http'], item['dashboard'], item['check_stream_num'], \
                    item['check_timeout'], ipList, cf)
    '''
    def __init__(self, name, dashboard, ipList, cf, num, screenLock, rtmp=None, http=None):
        wCheckStream.wTest.__init__(self, name)

        self.rtmp = rtmp
        self.http = http
        self.dashboard = dashboard
        self.ipList = ipList
        self.cf = cf
        self.num = num
        self.screenLock = screenLock
        self.terminate = False
        self.testTask = []
        self.result = []

    def printProgress(self):
        while not self.terminate:
            str = ''
            for ti in self.testTask:
                str = '%s%s: %d%%\n' % (str, ti.getName(), ti.testProgress())

            self.screenLock.acquire()
            sys.stderr.write(str)
            self.screenLock.release()
            time.sleep(1)

    def run(self):
        url = 'http://%s/v2/stat' % self.dashboard
        #print('fetch names from "%s"' % url)
        names = json.load(urllib.urlopen(url))

        testQueue = []

        count = 0
        for name in names['app']['live']:
            if count >= self.cf.checkStreamNum:
                break
            count += 1

            for ip in self.ipList:
                if self.http:
                    http_url = 'http://%s/%s/live/%s.flv' % (ip, self.http, name)
                    testQueue.append(http_url)

                if self.rtmp:
                    rtmp_url = 'rtmp://%s/live?vhost=%s/live/%s' % (ip, self.rtmp, name)
                    testQueue.append(rtmp_url)

        count = 0
        threadContainter = []

        for url in testQueue:
            ti = None
            if self.cf.testTool == 'ffprobe':
                ti = wCheckStream.wFfprobeStreamTest(url, url, self.cf.checkTime)
            else:
                ti = wCheckStream.wFfplayStreamTest(url, url, self.cf.checkTime)

            self.testTask.append(ti)

        prograssThread = threading.Thread(target=self.printProgress)
        prograssThread.start()

        for ti in self.testTask:
            t = threading.Thread(target=self.doTest, args=(ti, ), name=url)
            threadContainter.append({'thread':t, 'item':ti})
            t.start()
            count += 1
            wait = True

            if count >= self.cf.maxThreads or self.testTask.count(url) == (len(self.testTask) - 1):
                while wait:
                    for v in threadContainter:
                        v['thread'].join(0.5)

                        if not v['thread'].isAlive():
                            self.result.append(v['item'])
                            count -= 1

                            if not (self.testTask.count(url) == len(self.testTask) - 1) or len(threadContainter) == 1:
                                threadContainter.remove(v)
                                wait = False
                                break

        self.terminate = True
        prograssThread.join()


    def doTest(self, ti):
        #print('%s test start!' % ti.getName())
        ti.startTest()
        #print('%s test finished!' % ti.getName())

    def getResult(self):
        return self.result

class wTester():
    def __init__(self):
        self.checkList = []
        self.checkFinishedList = []

    def add(self, item):
        self.checkList.append(item)

    def run(self):
        threadContainter = []
        for item in self.checkList:
            t = threading.Thread(target=item.run, args=(), name=item.getName())
            t.start()
            threadContainter.append(t)

        for t in threadContainter:
            t.join()

        for item in self.checkList:
            tis = item.getResult()
            for ti in tis:
                print(ti.getResult())


def main():
    parser = argparse.ArgumentParser(description='online stream test tool, auto pull online stream to play or analyze.')
    parser.add_argument('-i', '--ip', nargs='+', help='server ip which will be test')
    parser.add_argument('-if', '--ipfile', nargs='+', help='the file contains server ips which will be test')
    parser.add_argument('-t', '--tool', nargs='?', default='ffprobe', choices=['ffplay', 'ffprobe'], help='the tool which to use for test') 
    parser.add_argument('--max-thread', nargs='?', default=1, type=int, help='how much threads per user test use')
    parser.add_argument('-s', '--stream-num', nargs='?', default=1, type=int, help='how much stream per user test')
    parser.add_argument('--check-time', nargs='?', default=60, type=int, help='how long per stream test.(seconds)')
    cmdArgs = parser.parse_args()

    print(cmdArgs)
    ipList = cmdArgs.ip if cmdArgs.ip else []
    testTool = cmdArgs.tool

    if cmdArgs.ipfile:
        for ipfile in cmdArgs.ipfile:
            for ip in open(ipfile, 'r'):
                ipList.append(ip.strip(' \r\n'))

    if len(ipList) == 0:
        print('ip list list was empty!')
        parser.print_help()
        exit(2)

    tj = json.loads(wCheckJson)
    cf = wConfig(int(cmdArgs.max_thread), int(cmdArgs.stream_num), int(cmdArgs.check_time), testTool)
    t = wTester()
    screenLock = threading.Lock()

    num = 0
    for item in tj['items']:
        num += 1
        ti = wUserTest(item['name'], item['dashboard'], ipList, cf, num, screenLock, rtmp=item['rtmp'], http=item['http'])
        t.add(ti)

    t.run()

if __name__ == '__main__':
    main()
