
'''
    Copyright (C) Wang Linsen
'''

import subprocess
import argparse

def main():

    parser = argparse.ArgumentParser(description='infinite loop to check online streams from the servers')
    parser.add_argument('-i', '--ip', nargs='+', help='server ip which will be test')
    parser.add_argument('-t', '--tool', nargs='?', default='ffprobe', choices=['ffplay', 'ffprobe'], help='the tool which to use for test') 
    cmdArgs = parser.parse_args()

    if not cmdArgs.ip:
        print('ip list empty!')
        parser.print_help()
        exit(2)

    args = ['python', 'wCheckOnlineStream.py', '-i'] 
    for ip in cmdArgs.ip:
        args.append(ip)

    args.append('-t')
    args.append(cmdArgs.tool)

    while True:
        testProcess = subprocess.Popen(args)
        testProcess.wait()

if __name__ == '__main__':
    main()
